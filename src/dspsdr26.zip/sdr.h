/* sdr.h */

#define SYS_TYPE			4				// dspPIC Based A/D board

#define MAJOR_VER			2
#define MINOR_VER			6

#define MAX_SPS				500
#define MAX_500_CHANS		4
#define MAX_CHANNELS		8
#define PACKETS_PER_SEC		10
#define NO_DATA_TIMER		1200			// 2 min

#define SLONG 				long
#define SINT 				short

#define ULONG				unsigned long
#define WORD				unsigned int
#define BYTE				unsigned char

#define USB_RST_PIN			LATBbits.LATB9		// pin 38

#define START_PIN			LATDbits.LATD3
#define BYTE_PIN			LATBbits.LATB8
#define BUSY_PIN			PORTAbits.RA11

#define LED_PIN				LATFbits.LATF0
#define PPS_PIN				PORTDbits.RD8

#define SW1_PIN				PORTBbits.RB11
#define SW2_PIN				PORTBbits.RB12
#define SW3_PIN				PORTFbits.RF6

#define TEST_PIN			LATBbits.LATB9
#define TEST1_PIN			LATBbits.LATB10

#define TICKS_SPS_500		2
#define TICKS_SPS_250		4
#define TICKS_SPS_10_200	5

#define AD_DATA_SIZE		( ( ( MAX_SPS * MAX_500_CHANS ) / PACKETS_PER_SEC ) * sizeof( SINT ) )
#define DATA_LEN 			( sizeof( PreHdr ) + sizeof( DataHdr ) + AD_DATA_SIZE + 2 )
#define IN_BUFFER_SIZE 		32
#define GPS_IN_QUEUE		32
#define GPS_IN_BUFFER_LEN	120
#define LOG_STR_LEN			48

#define GPS_OUT_LEN			52
#define MAX_GPS_OUT_LEN		128

#define TRUE				1
#define FALSE				0

#define TIME_REFV2_GARMIN	0		// Garmin 16/18
#define TIME_REFV2_MOT_NMEA	1		// Motorola NMEA
#define TIME_REFV2_MOT_BIN	2		// Motorola Binary
#define TIME_REFV2_USEPC	3		// PC's clock as reference
#define TIME_REFV2_SKG		6		// Sure Elect. Board
#define TIME_REFV2_4800		7		// OEM 4800
#define TIME_REFV2_9600		8		// OEM 9600

#define FG_PPS_HIGH_TO_LOW	0x0001	// config flags
#define FG_DISABLE_LED		0x0002
#define FG_WATCHDOG_CHECK	0x0004
#define FG_WAAS_ON			0x0008
#define FG_2D_ONLY			0x0010

// 8.0Mhz Xtal PLL=8
#define B4800				207
#define B9600				103
#define B19200				51
#define B38400				25
#define B57600				16

typedef struct  {
	ULONG notused;
	BYTE modeNumConverters;
} AdcInfo;

typedef struct  {						// serial data i/o header
	BYTE hdr[4];
	WORD len;
	BYTE type, flags;
} PreHdr;
	
typedef struct  {						// A/D packet header
	ULONG packetID, timeTick, ppsTick, gpsTOD;
	BYTE  loopError, gpsLockSts, gpsSatNum, gpsMonth, gpsDay, gpsYear;
} DataHdr;

typedef struct  {
	SLONG data;
	WORD notused;
} WWVLocInfo; 

typedef struct  {						// main system config info packet
	WORD flags;
	WORD sps;
	ULONG timeTick, spare;
	BYTE numChannels;
	BYTE timeRefType;
} ConfigInfo;

typedef struct  {
	BYTE sysType, majVer, minVer, numChannels; 
	WORD sps;
} StatusInfo;

typedef struct  {
	ULONG timeTick;
	BYTE reset;
} TimeInfo;
	
typedef struct  {
	SLONG timeAdjust;
	BYTE reset;
} TimeDiffInfo;
	
typedef struct  {						// ONCORE GPS data packet
	BYTE month, day;
	WORD year;	
	BYTE hours, minutes, seconds;
	ULONG fracSec;
	SLONG lat, lon, height, notused;
	WORD gpsSpeed, heading;
	WORD dop;
	BYTE dopt;
	BYTE visSat;
	BYTE trackedSat;
} GPSEa;

void Init();
void Restart();
void SendDataPacket();
void MakeHdr();
void CollectData();
void CollectDataAvg();
void CalcSampleAvg();
void CheckTime();
void NewGpsTimeNMEA();
void NewCommand();
void WaitForConfig();
void SendGpsLine();
void TimeTest();
void SetBaudRate( int startInt );
void CheckSendGarmin();
void EchoGps();
void CheckSendGarmin();
void NewGpsTimeBin();
void InitGps();
void SendAllGps();
void CheckSendGps();
void ClearGpsOut();
void QueueGpsPacket();
void SendTimeDiff();
void SetTimeInfo();
void SetTimeDiff();
void SetGpsTime();
void SaveAdjInfo();
void SendAck();
void GotoBootLdr();
void SwapWord( WORD *in );
void DelayMs( int ms );
void SendHost();
void delay_us();
void SetGpsBaud( int baud, int startRecvInt );
void SendLogString();
BYTE NewConfig();
BYTE SendGpsLineGarmin();
BYTE GpsCommCheck();
BYTE ParseGpsLine();
BYTE TestGpsLine();
BYTE ProcInData();
BYTE ReadBaudModeSwitch();
WORD XmitCount();
SINT ReadAD();
void Check100Ms();
BYTE WiFiTest();
