/* sdrgps.c */

char *gps18All[] = { "$PGRMO,,2", "$PGRMO,,4", "$PGRMO,GPGSA,1", "$PGRMO,GPGSA,1", "$PGRMO,GPRMC,1", 
					 "$PGRMO,GPGSV,1", "$PGRMO,PGRMT,1", 0 };

char *gps18Only2d[] = { "$PGRMO,,2", "$PGRMO,,4", "$PGRMI,,,,,,,R", "$PGRMI,,,,,,,R", "$PGRMO,,2", "$PGRMO,GPGGA,1", 
                      "$PGRMO,GPRMC,1", "$PGRMC,2,400,,,,,,,,,0,2,3,1", "$PGRMC1,1,1,1,,,,1,N,N,2,1", 0 };

char *gps18NormNoWAAS[] = { "$PGRMO,,2", "$PGRMO,,4", "$PGRMI,,,,,,,R", "$PGRMI,,,,,,,R", "$PGRMO,,2", "$PGRMO,GPGGA,1", 
                      "$PGRMO,GPRMC,1", "$PGRMC,,,,,,,,,,,,2,3,", "$PGRMC1,,,,,,,,N,,,,,", 0 };

char *gps18NormWAAS[] = { "$PGRMO,,2", "$PGRMO,,4", "$PGRMI,,,,,,,R", "$PGRMI,,,,,,,R", "$PGRMO,,2", "$PGRMO,GPGGA,1", 
                      "$PGRMO,GPRMC,1", "$PGRMC,,,,,,,,,,,,2,3,", "$PGRMC1,,,,,,,,W,,,,,", 0 };

char *gpsSKGNorm[] = { "$PMTK313,0", "$PMTK301,0", "$PMTK314,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0", 0 };

char *gpsSKGAll[] = { "$PMTK313,1", "$PMTK301,2", "$PMTK314,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0", 0 };

inline void SetGpsTime()
{
	ULONG gtime, adiff; 
	SLONG diff;
	
	setGpsTimeFlag = 0;
		
	gtime = gpsTimeOfDay * 1000;
	
	IEC0bits.T1IE = 0;
	
	addTime = subTime = 0;
	diff = gtime - ppsTick;
	if( diff < 0 ) {
		adiff = -diff;
		if( adiff > timeTick )
			timeTick = 86400000L - ( adiff - timeTick );
		else
			timeTick -= adiff;
	}
	else  {
		timeTick += diff;
		if( timeTick >= 86400000L )
			timeTick -= 86400000L;
	}
		
	if( resetTime )  {
		sampleTimer = 100 - ( timeTick % 100 ); 
		newSampleFlag = 0;
	}
	
	secTick = 1000 - ( timeTick % 1000 ) ;
	
	IEC0bits.T1IE = 1;
		
	if( resetTime )  {
		resetTime = 0;
		sampleCount = avgNumber = 0;
	}
}

void NewGpsTimeNMEA()
{
	if( gpsSendState )
		return;
		
	if( gpsWaitLines )  {
		--gpsWaitLines;
		return;
	}
		
	if( !TestGpsLine() )
		return;
		
	noGpsMessages = 0;
		
	if( !ParseGpsLine() )  {
		if( !sendGpsData && ( ++gpsBadCount >= 3 ) )  {
			gpsBadCount = 0;
			gpsSendState = 1;
			strcpy( (char *)logStr, "GPS Parse Error");
			sendLog = 1;
		}
		return;
	}
	
	gpsTimeOfDay = ( (long)gpsHour * 3600 ) + ( (long)gpsMin * 60 ) + (long)gpsSec;
	
	if( setGpsTimeFlag && ppsTick )
		SetGpsTime();
}
	
void NewGpsTimeBin()
{
	BYTE sum;
	WORD y, len;
	GPSEa *ea;
			
	if( gpsSendState )
		return;
	
	if( gpsWaitLines )  {
		--gpsWaitLines;
		return;
	}
	
	len = gpsMotLen - 1;
	sum = CalcChecksum( (BYTE *)gpsInBuffer,  len );
	if( sum != (BYTE)gpsInBuffer[ len ] )  {
		strcpy( (char *)logStr, "GPS Bin Checksum Error" );
		sendLog = 1;
		return;
	}
	if( gpsInBuffer[0] == 'B' )  {  
		gpsSendState = 1;
		strcpy( (char *)logStr, "GPS Type Error" );
		sendLog = 1;
		return;
	}
	noGpsMessages = 0;

	ea = (GPSEa *)&gpsInBuffer[2];
	gpsHour = ea->hours;
	gpsMin = ea->minutes;
	gpsSec = ea->seconds;
	gpsMonth = ea->month;
	gpsDay = ea->day;
	y = ea->year;
	SwapWord( &y );
	gpsYear = y - 2000;
	gpsSatNum = ea->trackedSat;
	
	if( gpsSatNum >= 3 )
		gpsLockChar = '1';
	else 
		gpsLockChar = '0';
	
	gpsTimeOfDay = ( (long)gpsHour * 3600 ) + ( (long)gpsMin * 60 ) + (long)gpsSec;
	
	if( setGpsTimeFlag && ppsTick )
		SetGpsTime();
}

BYTE ProcMotBinChar( BYTE chr )
{
	if( gpsMotCounter )  {
		gpsInBuffer[ gpsInCount++ ] = chr;
		--gpsMotCounter;
		if( !gpsMotCounter )  {
			gpsMotBody = gpsMotAt = 0;
			return 1;
		}
		return 0;
	}
	if( gpsMotBody )  {
		if( !gpsInCount )  {
			if( chr != 'E' && chr != 'B')  {
				gpsMotBody = 0;
				return 0;
			}
			gpsInBuffer[ gpsInCount++ ] = chr;
			return 0;
		}
		if( chr != 'a' && chr != 'b' )  {
			gpsInCount = 0;
			gpsMotBody = 0;
			return 0;
		}
		gpsInBuffer[ gpsInCount++ ] = chr;
		if( gpsInBuffer[0] == 'E' )  {
			gpsMotCounter = 70;
			gpsMotLen = 72;
		}
		else  {
			gpsMotCounter = 86;
			gpsMotLen = 88;
		}
		return 0;
	}
	if( chr == '@' )  {
		if( !gpsMotAt ) {
			gpsMotAt = 1;
			return 0;
		}
		gpsMotAt = 0;
		gpsInCount = 0;
		gpsMotBody = TRUE;
		return 0;
	}
	gpsMotAt = 0;
	return 0;
}

void MotBinary()
{
	strcpy( (char *)gpsOutLine, "$PMOTG,FOR,0\r\n" );
	tx2OutPtr = gpsOutLine;
	tx2OutCount = strlen( (char *)gpsOutLine );
	SendGPS();
}

void OncoreNMEA()
{
	gpsOutLine[0] = '@'; 
	gpsOutLine[1] = '@'; 
	gpsOutLine[2] = 'C'; 
	gpsOutLine[3] = 'i';
	gpsOutLine[4] = 1;
	gpsOutLine[5] = CalcChecksum( (BYTE *)&gpsOutLine[2], 3);
	gpsOutLine[6] = 0x0d;
	gpsOutLine[7] = 0x0a;
	tx2OutPtr = gpsOutLine;
	tx2OutCount = 8;
	SendGPS();
}

void ResetMot()
{
	gpsOutLine[0] = '@';
	gpsOutLine[1] = '@';
	gpsOutLine[2] = 'C';
	gpsOutLine[3] = 'f';
	gpsOutLine[4] = CalcChecksum( (BYTE *)&gpsOutLine[2], 2);
	gpsOutLine[5] = 0x0d;
	gpsOutLine[6] = 0x0a;
	tx2OutPtr = gpsOutLine;
	tx2OutCount = 7;
	SendGPS();
}

/* Send a start or stop command to the ONCORE GPS receiver */
void SendMotBin( BYTE type, BYTE num )
{
	gpsOutLine[0] = '@';
	gpsOutLine[1] = '@';
	gpsOutLine[2] = type;
	if(type == 'B')
		gpsOutLine[3] = 'b';
	else
		gpsOutLine[3] = 'a';
	gpsOutLine[4] = num;
	gpsOutLine[5] = CalcChecksum( (BYTE *)&gpsOutLine[2], 3 );
	gpsOutLine[6] = 0x0d;
	gpsOutLine[7] = 0x0a;
	tx2OutPtr = gpsOutLine;
	tx2OutCount = 8;
	SendGPS();
}

void GetGpsLineMotNMEA( BYTE line )
{
	char *ptr;
	
	strcpy( (char *)gpsOutLine, "$PMOTG," );
	ptr = (char *)&gpsOutLine[7];
	switch( line )  {
		case 0:		strcpy( ptr, "GGA,1" );
					break;
		case 1:		strcpy( ptr, "RMC,1" );
					break;
		case 2:		strcpy( ptr, "GSV,0" );
					break;
		case 3:		strcpy( ptr, "GSA,0" );
					break;
		case 4:		strcpy( ptr, "VTG,0" );
					break;
		case 5:		strcpy( ptr, "ZDA,0" );
					break;
		case 6:		strcpy( ptr, "GLL,0" );
					break;
		default:	return;		
	}
	strcpy( (char *)&gpsOutLine[ 12 ], "\r\n");
	tx2OutPtr = gpsOutLine;
	tx2OutCount = 14;
	SendGPS();
}

void GetGpsLineMotNmeaAll( BYTE line )
{
	char *ptr;
	
	strcpy( (char *)gpsOutLine, "$PMOTG," );
	ptr = (char *)&gpsOutLine[7];
	switch( line )  {
		case 0:		strcpy( ptr, "RMC,1" );
					break;
		case 1:		strcpy( ptr, "GSA,1" );
					break;
		case 2:		strcpy( ptr, "GSV,1" );
					break;
		default:	return;		
	}
	strcpy( (char *)&gpsOutLine[ 12 ], "\r\n");
	tx2OutPtr = gpsOutLine;
	tx2OutCount = 14;
	SendGPS();
}

BYTE GpsCommCheck()
{
	BYTE chr;
	
	while( gpsQueueInCount != gpsQueueOutCount )  {
		IEC1bits.U2RXIE = 0;
		chr = gpsInQueue[ gpsQueueOutCount ];
		if( ++gpsQueueOutCount >= GPS_IN_QUEUE )
			gpsQueueOutCount = 0;
		IEC1bits.U2RXIE = 1;

		gpsLastChar = chr;
		gpsTimer = 0;
		
		if( sendGpsData && !gpsSendState )  {
			if( ++gpsOutLen >= (MAX_GPS_OUT_LEN-1) )  {
				if( gpsOutSendLen )  {
					ClearGpsOut();
					strcpy( (char *)logStr, "GPS Send Overflow Error");
					sendLog = 1;
					return 0;
				}
				else
					QueueGpsPacket();
			}
			*gpsOutBuffPtr++ = chr;
			gpsOutSum ^= chr;
		}
			
		if( timeRefType == TIME_REFV2_MOT_BIN )  {
			if( ProcMotBinChar( chr ) )
				return 1;
			continue;
		}

		if( chr == 0x0d )
			continue;
			
		if( !gpsInCount )  {
			if( chr == '$' )  {
				gpsInCount = 1;
				gpsInBuffer[0] = chr;
			}
			continue;
		}
		if( gpsInCount >= ( GPS_IN_BUFFER_LEN-1 ) )  {
			gpsInCount = 0;
			strcpy( (char *)logStr, "GPS Input Overflow Error");
			sendLog = 1;
			return 0;
		}
		if( chr == 0x0a )  {
			gpsInBuffer[ gpsInCount ] = 0;
			gpsInCount = 0;
			return 1;
		}
		gpsInBuffer[ gpsInCount++ ] = chr;
	}
	return 0;
}

void QueueGpsPacket()
{
	BYTE *buff;
	PreHdr *pHdr;
	int len;

	if( gpsOutIdx )
		buff = gpsOutBuffer1; 
	else
		buff = gpsOutBuffer;
	
	pHdr = (PreHdr *)buff;
	memcpy( pHdr->hdr, hdrStr, 4);	// make the header
	len = gpsOutLen;
	pHdr->len = len + 1;			// 1 more for checksum
	pHdr->type = 'g';
	pHdr->flags = 0x81;
	gpsOutSum ^= buff[4];
	gpsOutSum ^= buff[5];
	gpsOutSum ^= buff[6];
	gpsOutSum ^= buff[7];
	buff[ len + sizeof(PreHdr) ] = gpsOutSum; 
	gpsOutSendPtr = buff;
	if( gpsOutIdx )  {
		gpsOutIdx = 0;
		gpsOutBuffPtr = &gpsOutBuffer[ sizeof( PreHdr ) ];	
	}
	else  {
		gpsOutIdx = 1;
		gpsOutBuffPtr = &gpsOutBuffer1[ sizeof( PreHdr ) ];	
	}
	gpsOutSum = gpsOutLen = 0;
	if( skipGpsSend )
		--skipGpsSend;
	if( !skipGpsSend )
		gpsOutSendLen = len + ( sizeof( PreHdr ) + 1 );		// one more for the checksum
}
	
BYTE TestGpsLine()
{
	char *ptr, *end, chr, *line;
	register BYTE sum, num;
	register WORD len;
	
	line = (char *)&gpsInBuffer[1]; 
	sum = 0;
	if(!( end = strchr( line, '*' ) ) )  {
		strcpy( (char *)logStr, "GPS Error No *");
		sendLog = 1;
		return( 0 );
	}
	*end++ = 0;
	if( ( len = strlen(line) ) < 2 )  {
		strcpy( (char *)logStr, "GPS Length Error");
		sendLog = 1;
		return( 0 );
	}
	ptr = line;
	while(len--)
		sum = sum ^ *ptr++;
	num = (sum >> 4) & 0x0f;
	if( num > 9 )
		chr = ( num-10 ) + 'A';
	else
		chr = num + '0';
	if( chr != *end++ )
		return( 0 );
	num = sum & 0x0f;
	if( num > 9 )
		chr = ( num-10 ) + 'A';
	else
		chr = num + '0';
	if( chr != *end )  {
		strcpy( (char *)logStr, "GPS Checksum Error");
		sendLog = 1;
		return(0);
	}
	return(1);
}

BYTE ParseGpsLine()
{
	register char *ptr, lckChr;
	static char lockWait = 0;
	
	if( !memcmp( &gpsInBuffer[1], "GPGGA,", 6 ) )  {
		ptr = (char *)&gpsInBuffer[ 7 ];
		if( ! ( ptr = SkipComma( (char *)gpsInBuffer, 7 ) ) )
			return FALSE;
		ggaLockChar = *ptr;
		gpsSatNum = (char)GetSatNum(ptr + 2);
		return TRUE;
	}
		
	if( !memcmp( &gpsInBuffer[1], "GPRMC,", 6 ) )  {
		if( !needTimeFlag )				// only allow one RMC after 1PPS pulse
			return TRUE;
		needTimeFlag = FALSE;
		ptr = (char *)&gpsInBuffer[ 7 ];
		gpsHour = GetHMS( ptr );
		gpsMin = GetHMS( &ptr[ 2 ] );
		gpsSec = GetHMS( &ptr[ 4 ] );
		if( ! ( ptr = FindComma( ptr ) ) )
			return FALSE;
		lckChr = *ptr;
		if( lckChr == 'A' )  {
			if( lockWait )  {
				--lockWait;			
				gpsLockChar = '0';			// send not locked back to host
			}
			else if( ggaLockChar == '2' )	// send diff locked
				gpsLockChar = '2';
			else
				gpsLockChar = '1';			// send good lock
		}	
		else if( lckChr == 'V' )  {
			gpsLockChar = '0';
			lockWait = 3;
		}
		else
			return TRUE;
			
		if( ! ( ptr = SkipComma( (char *)gpsInBuffer, 10 ) ) )  {
			strcpy( (char *)logStr, "GPS RMC SkipComma Error");
			sendLog = 1;
			return FALSE;
		}
		if( *ptr == ',' )
			gpsDay = gpsMonth = gpsYear = 0;
		else  {
			gpsDay = GetHMS( ptr );
			gpsMonth = GetHMS( &ptr[ 2 ] );
			gpsYear = GetHMS( &ptr[ 4 ] );
		}
		gpsBadCount = 0;
		return TRUE;
	}

	if( timeRefType == TIME_REFV2_4800 || timeRefType == TIME_REFV2_9600 )
		return TRUE;
	
	return FALSE;
}

BYTE SendGpsLineGarmin()
{
	register BYTE *out, sum, num; 
	char *str = 0;
	WORD len;
		
	if( timeRefType == TIME_REFV2_4800 || timeRefType == TIME_REFV2_9600 )
		return 0;
		
	if( timeRefType == TIME_REFV2_SKG )  {
		if( sendAllGps )
			str = gpsSKGAll[ gpsSendLine ];
		else
			str = gpsSKGNorm[ gpsSendLine ];
	}
	else  {
		if( sendAllGps )
			str = gps18All[ gpsSendLine ];
		else if( config.flags & FG_2D_ONLY )
			str = gps18Only2d[ gpsSendLine ];
		else if( config.flags & FG_WAAS_ON )
			str = gps18NormWAAS[ gpsSendLine ];
		else
			str = gps18NormNoWAAS[ gpsSendLine ];
	}
	
	if( !str )
		return 0;
	
	strcpy( (char *)gpsOutLine, str );
	len = strlen( (char *)gpsOutLine ) - 1;
	sum = CalcChecksum( &gpsOutLine[1], len );
	out = &gpsOutLine[ len + 1 ];
	*out++ = '*'; 
	num = ( sum >> 4 ) & 0x0f;
	if( num > 9 )
		*out++ = ( num - 10 ) + 'A';
	else
		*out++ = num + '0';
	num = sum & 0x0f;
	if( num > 9 )
		*out++ = ( num - 10 ) + 'A';
	else
		*out++ = num + '0';
	*out++ = 0x0d;
	*out++ = 0x0a;
	*out = 0;
	tx2OutPtr = gpsOutLine;
	tx2OutCount = len + 6;
	SendGPS();
	return 1;
}

void CheckSendGarmin()
{
	if( tx2OutCount || gpsSendWait )
		return;
		
	if( timeRefType == TIME_REFV2_SKG )  {
		if( gpsTimer > 1200 )  {		// a little over 1 second
			gpsTimer = 0;
			strcpy( (char *)logStr, "SKG Init Error");
			sendLog = 1;
		}
		else if( ( gpsLastChar != 0x0a ) || ( gpsTimer < 50 ) )
			return;		
	}
		
	if( gpsSendState == 1 )  {
		gpsSendLine = 0;
		if( sendAllGps )
			SendGpsLineGarmin();
		else  {
			if( gpsReset )  {
				gpsReset = 0;
				SendGpsLineGarmin();
				gpsSendWait = 30;
			}
		}
		gpsSendLine = 1;
		gpsSendState = 2;
		return;
	}
		
	if( !SendGpsLineGarmin() )  {
		sendAllGps = 0;
		gpsWaitLines = 5;
		gpsSendState = 0;
		ClearGpsOut();
	}
	else  {
		++gpsSendLine;
		++gpsSendState;
		gpsSendWait = 30;
	}
}

void CheckSendMotNMEA()
{
	if( gpsSendCount || gpsSendWait )
		return;
		
	if( gpsSendState == 1 )  {
		SetGpsBaud( 9600, 1 );
		gpsSendLine = 0;
		if( gpsReset )  {
			gpsReset = 0;
			ResetMot();
		}
		++gpsSendState;
		return;
	}
	if( gpsSendState == 2 || gpsSendState == 3 )  {
		OncoreNMEA();
		++gpsSendState;
		gpsSendWait = 2;
		return;
	}		
	if( gpsSendState == 4 )  {
		SetGpsBaud( 4800, 1 );
		++gpsSendState;
		return;
	}		
		
	if( gpsSendState >= 5 && gpsSendState <= 12 )  {
		GetGpsLineMotNMEA( gpsSendLine++ );
		++gpsSendState;
		gpsSendWait = 4;
		return;
	}
	gpsWaitLines = 10;
	gpsSendState = 0;
	ClearGpsOut();
}

void CheckSendMotNmeaNormal()
{
	if( gpsSendCount || gpsSendWait )
		return;
		
	if( gpsSendState >= 1 && gpsSendState <= 7 )  {
		if( gpsSendState == 1 )
			gpsSendLine = 0;
		GetGpsLineMotNMEA( gpsSendLine++ );
		++gpsSendState;
		gpsSendWait = 4;
		return;
	}
	gpsWaitLines = 10;
	gpsSendState = 0;
	sendNormalGps = 0;
	ClearGpsOut();
}

void CheckSendMotNmeaAll()
{
	if( gpsSendCount || gpsSendWait )
		return;
	
	if( gpsSendState >= 1 && gpsSendState <= 3 )  {
		if( gpsSendState == 1 )
			gpsSendLine = 0;
		GetGpsLineMotNmeaAll( gpsSendLine++ );
		++gpsSendState;
		gpsSendWait = 4;
		return;
	}
	gpsWaitLines = 10;
	gpsSendState = 0;
	ClearGpsOut();
}

void CheckSendMotBin()
{
	if( gpsSendCount || gpsSendWait )
		return;
		
	if( gpsSendState == 1 )  {
		SetGpsBaud( 4800, 1 );
		gpsSendLine = 0;
		++gpsSendState;
		return;
	}
		
	if( gpsSendState == 2 || gpsSendState == 3 )  {
		MotBinary();
		++gpsSendState;
		gpsSendWait = 2;
		return;
	}		
	if( gpsSendState == 4 )  {
		SetGpsBaud( 9600, 1 );
		++gpsSendState;
		return;
	}		
	if( gpsSendState == 5 )  {
		SendMotBin( 'E', 1 );
		++gpsSendState;
		gpsSendWait = 2;
		return;
	}
	if( gpsSendState == 6 )  {
		SendMotBin( 'B', 0 );
		++gpsSendState;
		gpsSendWait = 2;
		return;
	}
	gpsWaitLines = 10;
	gpsSendState = 0;
	ClearGpsOut();
}

void CheckSendMotBinAll()
{
	if( gpsSendCount || gpsSendWait )
		return;
		
	if( gpsSendState == 1 )  {
		SendMotBin( 'B', 1 );
		++gpsSendState;
		return;
	}
	gpsWaitLines = 10;
	gpsSendState = 0;
	sendAllGps = 0;
	ClearGpsOut();
}

void CheckSendMotBinNormal()
{
	if( gpsSendCount || gpsSendWait )
		return;
		
	if( gpsSendState == 1 )  {
		SendMotBin( 'B', 0 );
		++gpsSendState;
		return;
	}
	gpsWaitLines = 10;
	gpsSendState = 0;
	sendAllGps = 0;
	sendNormalGps = 0;
	ClearGpsOut();
}

void CheckSendGps()
{
	if( timeRefType == TIME_REFV2_4800 || timeRefType == TIME_REFV2_9600 )  {
		gpsSendState = 0;
		gpsWaitLines = 5;
		return;
	}
	if( timeRefType == TIME_REFV2_GARMIN || timeRefType == TIME_REFV2_SKG )
		CheckSendGarmin();
	else if( timeRefType == TIME_REFV2_MOT_NMEA  )  {
		if( sendAllGps )
			CheckSendMotNmeaAll();
		else if( sendNormalGps )
			CheckSendMotNmeaNormal();
		else
			CheckSendMotNMEA();
	}
	else if( timeRefType == TIME_REFV2_MOT_BIN )  {
		if( sendAllGps )
			CheckSendMotBinAll();
		else if( sendNormalGps )
			CheckSendMotBinNormal();
		else
			CheckSendMotBin();
	}
	else
		gpsSendState = 0;
}

void InitGps()
{
	IEC1bits.U2TXIE = 0;
	IFS1bits.U2TXIF = 0;
	tx2OutCount = 0;
	if( timeRefType == TIME_REFV2_SKG )
		gpsReset = 1;
	gpsSendState = 1;
	gpsInCount = 0;
	if( timeRefType == TIME_REFV2_MOT_BIN || timeRefType == TIME_REFV2_SKG || timeRefType == TIME_REFV2_9600 )
		SetGpsBaud( 9600, TRUE );
	else
		SetGpsBaud( 4800, TRUE );
	ClrWdt();
}

void ClearGpsOut()
{
	gpsOutIdx = 0;
	gpsOutSendLen = gpsOutLen = gpsOutSum = 0;
	gpsOutBuffPtr = &gpsOutBuffer[ sizeof( PreHdr ) ];	
}

void SetGpsBaud( int baud, int startInt )
{
	WORD c1, c2, data, div;
	
	IEC1bits.U2TXIE = 0;
	IEC1bits.U2RXIE = 0;
	CloseUART2();
	
	if( baud == 4800 )
		div = B4800;
	else
		div = B9600;

	c1 = UART_EN & UART_IDLE_CON & UART_DIS_WAKE & UART_DIS_LOOPBACK &
	    	UART_DIS_ABAUD & UART_NO_PAR_8BIT &	UART_1STOPBIT;
	c2 = UART_TX_PIN_NORMAL & UART_TX_ENABLE & UART_ADR_DETECT_DIS & 
		UART_RX_OVERRUN_CLEAR;
	OpenUART2( c1, c2, div );
	
	if ( U2STAbits.OERR )
		U2STAbits.OERR = 0;
	
	data = U2STA;
	data &= 0xff3f;
	U2STA = data ;
	
	gpsQueueInCount = gpsQueueOutCount = 0;
	if( startInt )
		IEC1bits.U2RXIE = 1;
}

void EchoGps()
{
	BYTE escCnt, chr;
	WORD c1, c2, data, div;
	
	escCnt = 0;
	
	if( timeRefType == TIME_REFV2_MOT_BIN || timeRefType == TIME_REFV2_SKG || timeRefType == TIME_REFV2_9600 )  {
		SetGpsBaud( 9600, FALSE );
		div = B9600;
	}
	else  {
		SetGpsBaud( 4800, FALSE );
		div = B4800;
	}
	
	CloseUART1();
	c1 = UART_EN & UART_RX_TX& UART_IDLE_CON & UART_DIS_WAKE & UART_DIS_LOOPBACK &
	    	UART_DIS_ABAUD & UART_NO_PAR_8BIT &	UART_1STOPBIT;
	c2 = UART_TX_PIN_NORMAL & UART_TX_ENABLE & UART_ADR_DETECT_DIS & 
		UART_RX_OVERRUN_CLEAR;
	OpenUART1( c1, c2, div  );
	
	data = U1STA;
	data &= 0xff3f;
	U1STA = data ;
		
	while( 1 )  {
		if( DataRdyUART1() )  {
			chr = ReadUART1();
			if( chr == 0x1b )  {
				if( ++escCnt >= 3 )
					break;
			}
			else
				escCnt = 0;
			while( BusyUART2() );
			WriteUART2( chr );
		}
		if( DataRdyUART2() )  {
			chr = ReadUART2();
			while( BusyUART1() );
			WriteUART1( chr );
		}
		ClrWdt();
	}
	echoMode = 0;
	baudSwitch = ReadBaudModeSwitch();
	SetBaudRate( TRUE );
	if( refGps )
		InitGps();
}
