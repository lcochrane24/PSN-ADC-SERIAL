/* sdr.c */

#include "p30F3014.h"

_FOSC( CSW_FSCM_OFF & XT_PLL8 );
_FWDT(WDT_OFF & WDTPSA_64 & WDTPSB_4);
_FBORPOR( PBOR_ON & BORV_42 & PWRT_16 & MCLR_EN );
_FGS( CODE_PROT_OFF );

#include <uart.h>
#include <stdio.h>
#include <string.h>
#include "sdr.h"

volatile ULONG timeTick, ppsTick, timeStamp;
volatile WORD txOutCount, secTick, minCnt, minLowCnt, noDataCounter, gpsTimer;
volatile BYTE *txOutPtr, *tx2OutPtr, *gpsOutSendPtr, *inPtr;
volatile BYTE tx2OutCount, gpsOutSendLen, newSampleFlag;
volatile BYTE hdrState, inDataLen, inPacketLen, ledPPS; 
volatile BYTE inSum, commTimer, newCommandFlag, checkErr;
volatile BYTE gpsInCount, gpsQueueInCount, gpsQueueOutCount;
volatile BYTE sampleTimer, sampleTimerValue, addTime, subTime;
volatile BYTE refGps, refLoc, ppsLowHiFlag, ppsHiToLowFlag;
volatile BYTE minHi, minHighCnt, curInfoIn, curInfoOut;
volatile BYTE gpsInQueue[ GPS_IN_QUEUE] __attribute__ ((aligned (2)));
volatile BYTE needTimeFlag, watchdogCheck;

ULONG packetID, gpsTimeOfDay;
SLONG dataSamples[MAX_CHANNELS], sampleAvgNumber;
WORD portD, sampleDataLen, spsRate;
DataHdr *currHdr;
SINT *adDataPtr;

BYTE dataPacket[DATA_LEN] __attribute__ ((aligned (2)));
BYTE dataPacket1[DATA_LEN] __attribute__ ((aligned (2)));
BYTE auxPacket[64] __attribute__ ((aligned (2)));
BYTE hdrStr[4] __attribute__ ((aligned (2)));
BYTE gpsOutBuffer[ MAX_GPS_OUT_LEN+sizeof(PreHdr)+4 ] __attribute__ ((aligned (2)));
BYTE gpsOutBuffer1[ MAX_GPS_OUT_LEN+sizeof(PreHdr)+4 ] __attribute__ ((aligned (2)));
BYTE gpsInBuffer[ GPS_IN_BUFFER_LEN ] __attribute__ ((aligned (2)));
BYTE logStr[LOG_STR_LEN] __attribute__ ((aligned (2)));
BYTE inBuffer[IN_BUFFER_SIZE] __attribute__ ((aligned (2)));

BYTE setGpsTimeFlag, outBuffer, sendTimeDiff;
BYTE newInData, sendLog, exitLoop, sendStatus, goodConfig, baudSwitch;
BYTE echoMode, newEchoChr, resetTime, skipGpsSend, sendAckFlag, echoChar;
BYTE adLoopCount, loopError, avgNumber, avgNumberValue, adShiftNum;
BYTE sampleCount, sampleCountTest, channel, numChannels, timeRefType;
BYTE gpsHour, gpsMin, gpsSec, sendHour, sendMin, sendSec;
BYTE gpsSatNum, gpsWaitLines, gpsMonth, gpsDay, gpsYear;
BYTE gpsMotCounter, gpsMotLen, gpsMotBody, gpsMotAt;
BYTE gpsOutLine[GPS_OUT_LEN], gpsSendCount, gpsSendState, gpsBadCount, ggaLockChar; 
BYTE gpsSendWait, gpsSendLine, gpsReset, gpsOutLen, gpsOutSum, *gpsOutBuffPtr; 
BYTE gpsOutIdx, sendGpsData, sendAllGps, sendNormalGps, gpsLockChar, gpsLastChar;

BYTE modeSwitch, noDataFlag;

ConfigInfo config;
WWVLocInfo wwvLocInfo;

int noGpsMessages;

#include "utils.c"
#include "sdrgps.c"
#include "sdrint.c"

int main()
{
	Init();
		
	while( TRUE )  {
		if( exitLoop )
			GotoBootLdr();
			
		Restart();
		
		WaitForConfig();
		
		if( !NewConfig() )
			continue;
				
		while( !exitLoop )  {
			if( newSampleFlag )
				++loopError;
			
			while( !newSampleFlag );
			newSampleFlag = 0;
				
			if( !sampleCount && !avgNumber )
				MakeHdr();
		
			if( avgNumberValue > 1 )
				CollectDataAvg();
			else
				CollectData();
			
			if( ++avgNumber >= avgNumberValue )  {
				avgNumber = 0;
				if( avgNumberValue > 1 )
					CalcSampleAvg();
				if( ++sampleCount >= sampleCountTest )  {
					sampleCount = 0;
					SendDataPacket();
					Check100Ms();
					if( exitLoop )
						break;
				}
			}									
				
			if( refGps )  {
				if( GpsCommCheck() )  {
					if( timeRefType == TIME_REFV2_MOT_BIN )
						NewGpsTimeBin();
					else
						NewGpsTimeNMEA();
					continue;
				}
		    	else if( gpsSendState )
					CheckSendGps();						
			}
										
			if( !txOutCount )  {
				if( sendStatus ) 
					SendStats();
				else if( sendTimeDiff )
					SendTimePacket();
				else if( sendLog )
					SendLogString();
				else if( sendAckFlag )
					SendAck();
			}
				
			if( newCommandFlag )  {
				newCommandFlag = 0;
				noDataCounter = 0;
				noDataFlag = 0;
				hdrState = 0;
				NewCommand();
				if( exitLoop )
					break;
			}
				
			if( checkErr )  {
				checkErr = 0;
				strcpy( (char *)logStr, "Checksum Error");
				sendLog = 1;
			}
		}
	}
}

void Check100Ms()
{
	if( gpsSendWait )  {
		--gpsSendWait;
		if( !gpsSendWait )
			noGpsMessages = 0;
	}
	if( refGps && ( ++noGpsMessages >= 900 ) )  {
		noGpsMessages = 0;
		strcpy( (char *)logStr, "No GPS Data");
		sendLog = 1;
	}
	if( hdrState && ( hdrState != 3 ) && ( ++commTimer >= 15 ) )  {
		hdrState = 0;
		strcpy( (char *)logStr, "Input Comm Timeout");
		sendLog = 1;
	}
	if( watchdogCheck && ( ++noDataCounter >= NO_DATA_TIMER ) )  {
		exitLoop = noDataFlag = 1;
		SendLogMsg( "No Data TmOut" );
	}
}

void MakeHdr()
{
	if( outBuffer )  {
		currHdr = (DataHdr *)&dataPacket1[ sizeof( PreHdr ) ];
		adDataPtr = (SINT *)&dataPacket1[ ( sizeof( PreHdr ) + sizeof( DataHdr ) ) ];
	}
	else  {
		currHdr = (DataHdr *)&dataPacket[ sizeof( PreHdr ) ];
		adDataPtr = (SINT *)&dataPacket[ ( sizeof( PreHdr ) + sizeof( DataHdr ) ) ];
	}
	IEC0bits.T1IE = 0;
	currHdr->timeTick = timeTick;
	currHdr->ppsTick = ppsTick;
	IEC0bits.T1IE = 1;
	currHdr->gpsMonth = gpsMonth;
	currHdr->gpsDay = gpsDay;
	currHdr->gpsYear = gpsYear;
	currHdr->gpsTOD = gpsTimeOfDay;
	currHdr->gpsSatNum = gpsSatNum;
	currHdr->gpsLockSts = gpsLockChar;
	currHdr->loopError = loopError;
	currHdr->packetID = packetID;
	if( avgNumberValue > 1 )
		memset( dataSamples, 0, sizeof( dataSamples ) );
}

void CollectData()
{
	BYTE c, count;
	SLONG adData;
		
	c = numChannels;
	while( c-- )  {
		adData = 0;
		count = adLoopCount; 
		while( count-- )
			adData += ReadAD();
		LATD = portD | ++channel;
		if( adShiftNum )  {
			if( adData < 0 )  {
				adData = -adData;
				adData >>= adShiftNum;
				adData = -adData;
			}
			else
				adData >>= adShiftNum;
			*adDataPtr++ = (SINT)adData;
		}
		else
			*adDataPtr++ = (SINT)( adData / (SLONG)adLoopCount );
	}
	channel = 0;
	LATD = portD;
	ClrWdt();
}

void CalcSampleAvg()
{
	BYTE c;
	
	for( c = 0; c != numChannels; c++ )  {
		*adDataPtr++ = (SINT)( dataSamples[c] / sampleAvgNumber); 
		dataSamples[c] = 0;
	}
}

void CollectDataAvg()
{
	BYTE c, count;
	SLONG adData;
				
	for( c = 0; c != numChannels; c++ )  {
		adData = 0;
		count = adLoopCount; 
		while( count-- )
			adData += ReadAD();
		LATD = portD | ++channel;
		dataSamples[c] += adData;
	}
	channel = 0;
	LATD = portD;
	ClrWdt();
}

SINT ReadAD()
{
	WORD ret;
	BYTE d;
		
	BYTE_PIN = 1;
	__asm__ volatile("disi #0x3FFF"); /* disable interrupts */
	START_PIN = 0;
	asm( "nop" );
	asm( "nop" );
	START_PIN  = 1;
	DISICNT = 0x0000;
	delayUs();	
	while( !BUSY_PIN );
	delayUs();	
	ret = PORTB & 0xff;
	BYTE_PIN = 0;
	asm( "nop" );
	ret <<= 8;
	d = PORTB;
	ret |= d;
	return ret;
}

void SendDataPacket()
{
	PreHdr *phdr;
	BYTE sum;
	WORD len;
		
	len = sampleDataLen + sizeof( DataHdr );
	
	while( txOutCount );

	if( outBuffer )  {
		memcpy( dataPacket1, hdrStr, 4 );
		phdr = (PreHdr *)dataPacket1;
		phdr->len = len + 1;			// one more for checksum
		phdr->type = 'D';
		phdr->flags = 0x81;
		sum = CalcChecksum( &dataPacket1[ 4 ], len + 4 );
		dataPacket1[ len + sizeof(PreHdr) ] = sum; 
		txOutPtr = dataPacket1;
		outBuffer = 0;
	}
	else  {
		memcpy( dataPacket, hdrStr, 4 );
		phdr = (PreHdr *)dataPacket;
		phdr->len = len + 1;			// one more for checksum
		phdr->type = 'D';
		phdr->flags = 0x81;
		sum = CalcChecksum( &dataPacket[ 4 ], len + 4 );
		dataPacket[ len + sizeof(PreHdr) ] = sum; 
		txOutPtr = dataPacket;
		outBuffer = 1;
	}
	txOutCount = len + sizeof( PreHdr ) + 1;	// one more for the checksum
	SendHost();
	++packetID;
}

BYTE NewConfig()
{
	while( txOutCount );

	IFS0bits.U1RXIF = 0;		/* disable interrupts */
    IFS0bits.U1TXIF = 0;
    IFS1bits.U2RXIF = 0;
    IFS1bits.U2TXIF = 0;	
	IEC0bits.T1IE = 0;
	
	memcpy( &config, &inBuffer[1], sizeof( ConfigInfo ) );
	
	numChannels = config.numChannels;
	timeRefType = config.timeRefType;
	timeTick = config.timeTick;
	spsRate = config.sps;
		
	if( !numChannels || ( numChannels > 8 ) )  {
		numChannels = 1;
		return 0;
	}
	if( spsRate == 500 && numChannels > 4 )  {
		numChannels = 1;
		return 0;
	}
		
	if( timeRefType == TIME_REFV2_GARMIN || timeRefType == TIME_REFV2_MOT_NMEA ||  
			timeRefType == TIME_REFV2_MOT_BIN || timeRefType == TIME_REFV2_SKG ||
			timeRefType == TIME_REFV2_4800 || timeRefType == TIME_REFV2_9600 )  {
		refGps = TRUE;
		refLoc = 0;
	}
	else if( timeRefType == TIME_REFV2_USEPC )  {
		refLoc = TRUE;
		refGps = 0;
	}		
	else  {
		refLoc = TRUE;
		refGps = 0;
		return 0;
	}
	
	if( config.flags & FG_PPS_HIGH_TO_LOW )
		ppsHiToLowFlag = 1;
	else
		ppsHiToLowFlag = 0;

	if( spsRate == 10 )  {
		sampleTimerValue = TICKS_SPS_10_200;
		sampleCountTest = 1;
		avgNumberValue = 20;
		adLoopCount = 40;
		adShiftNum = 0;
	}
	else if( config.sps == 20 )  {
		sampleTimerValue = TICKS_SPS_10_200;
		sampleCountTest = 2;
		avgNumberValue = 10;
		adLoopCount = 40;
		adShiftNum = 0;
	}
	else if( config.sps == 50 )  {
		sampleTimerValue = TICKS_SPS_10_200;
		sampleCountTest = 5;
		avgNumberValue = 4;
		adLoopCount = 40;
		adShiftNum = 0;
	}
	else if( config.sps == 100 )  {
		sampleTimerValue = TICKS_SPS_10_200;
		sampleCountTest = 10;
		avgNumberValue = 2;
		adLoopCount = 40;
		adShiftNum = 0;
	}
	else if( config.sps == 200 )  {
		sampleTimerValue = TICKS_SPS_10_200;
		sampleCountTest = 20;
		avgNumberValue = 1;
		adLoopCount = 40;
		adShiftNum = 0;
	}
	else if( config.sps == 250 )  {
		sampleTimerValue = TICKS_SPS_250;
		sampleCountTest = 25;
		avgNumberValue = 1;
		adLoopCount = 16;
		adShiftNum = 4;
	}
	else if( config.sps == 500 && numChannels <= 4 )  {
		sampleTimerValue = TICKS_SPS_500;
		sampleCountTest = 50;
		avgNumberValue = 1;
		adLoopCount = 16;
		adShiftNum = 4;
	}
	else
		return 0;
	
	sampleAvgNumber = adLoopCount * avgNumberValue;
		
	if( config.flags & FG_DISABLE_LED )
		ledPPS = 0;
	else
		ledPPS = 1;
	
	if( config.flags & FG_WATCHDOG_CHECK )  {
		watchdogCheck = 1;
		RCONbits.SWDTEN = 1;
	}
	else  {
		watchdogCheck = 0;
		RCONbits.SWDTEN = 0;
	}
	
	Restart();
		
	exitLoop = 0;
	goodConfig = 1;
	
	ClrWdt();
	
	return 1;
}

void NewCommand()
{
	char cmd;
	
	cmd = inBuffer[0];
	if( cmd == 'T' )
		SetTimeInfo();
	else if( cmd == 'D' )
		SendTimeDiff();
	else if( cmd == 'R' )
		noDataCounter = 0;
	else if( cmd == 't' )  {
		setGpsTimeFlag = 1;
		resetTime = 0;
	}
	else if( cmd == 'i' )  {
		setGpsTimeFlag = 1;
		resetTime = 1;
	}
	else if( cmd == 'a' )  {
		addTime = 1;
		sendAckFlag = 1;
	}
	else if( cmd == 's' )  {
		subTime = 1;
		sendAckFlag = 1;
	}
	else if( cmd == 'S' )
		sendStatus = 1;
	else if( cmd == 'x')  {
		exitLoop = 1;
		sendAckFlag = 1;
	}
	else if( cmd == 'C' )  {
		if( !NewConfig() )
			exitLoop = 1;
	}
	else if( cmd == 'g' )  {
		gpsReset = 1;
		gpsSendState = 1;
	}
	else if( cmd == 'G' )
		gpsSendState = 1;
	else if( cmd == 'E' )  {
		EchoGps();
		exitLoop = 1;
	}
	else if( cmd == 'b' )  {
		GotoBootLdr();
	}
	else if( cmd == 'P' && !sendGpsData )  {
		if( timeRefType == TIME_REFV2_4800 || timeRefType == TIME_REFV2_9600 )  {
			sendGpsData = sendAllGps = 1;
		}
		else  {
			if( timeRefType == TIME_REFV2_SKG )
				gpsReset = 1;
			sendGpsData = sendAllGps = gpsSendState = 1;
			skipGpsSend = 3;
			gpsSendCount = 0;
		}
		ClearGpsOut();
	}
	else if( cmd == 'p' && sendGpsData )  {
		sendAllGps = 0;
		sendGpsData = 0;
		if( timeRefType == TIME_REFV2_4800 || timeRefType == TIME_REFV2_9600 )  {
			ClearGpsOut();
		}
		else  {
			if( timeRefType == TIME_REFV2_SKG )  {
				gpsReset = 1;
				sendNormalGps = 1;
			}
			else if( timeRefType == TIME_REFV2_GARMIN || timeRefType == TIME_REFV2_MOT_NMEA )
				sendNormalGps = 1;
			gpsSendState = 1;
			gpsSendCount = 0;
			ClearGpsOut();
		}
	}
	else if( cmd == 'd' )  {
		SetTimeDiff();
		sendAckFlag = 1;
	}
}

void Restart()
{
	hdrStr[0] = 0xaa; hdrStr[1] = 0x55; hdrStr[2] = 0x88; hdrStr[3] = 0x44;
	
	outBuffer = 0;
	txOutCount = 0;
	packetID = 0;
	subTime = addTime = 0;
	
	ppsTick = 0;
	gpsTimeOfDay = 0;
	noDataCounter = 0;
	noDataFlag = 0;
	gpsTimer = 0;
	gpsLastChar = 0;
	gpsLockChar = ggaLockChar = '0';
	gpsSatNum = 0;
	gpsSendState = 0;
	tx2OutCount = 0;
	sendStatus = 0;
	
	secTick = 1000;
	sampleTimer = sampleTimerValue;
	sampleDataLen = ( ( spsRate * (WORD)numChannels ) / 10 ) * 2;
	
	newSampleFlag = 0;
	sampleCount = 0;
	avgNumber = 0;		
	
	sendTimeDiff = 0;
	gpsInCount = gpsQueueInCount = gpsQueueOutCount = 0;
	loopError = hdrState = 0;
	gpsBadCount = gpsSendCount = 0;
	gpsReset = 0;
	setGpsTimeFlag = 0;
	gpsWaitLines = 5;
	gpsSendWait = 0;
	sendGpsData = sendAllGps = sendNormalGps = 0;
	echoMode = newEchoChr = 0;
	resetTime = 0;
	skipGpsSend = 0;
	sendAckFlag = 0;
				
	memset( dataSamples, 0, sizeof( dataSamples ) );
	
	gpsMotCounter = gpsMotLen = 0;
	gpsMotBody = gpsMotAt = 0;

	gpsMonth = gpsDay = gpsYear = 0;
	
	channel = 0;
	portD = 0x08;
	LATD = portD;
	
	ClearGpsOut();
	
	noGpsMessages = 0;
	
	if( ppsHiToLowFlag )  {
		if( !PPS_PIN )
			ppsLowHiFlag = 0;
		else
			ppsLowHiFlag = 1;
	}
	else  {
		if( PPS_PIN )
			ppsLowHiFlag = 0;
		else
			ppsLowHiFlag = 1;
	}
	
	IEC0bits.T1IE = 1;		/* enable interrupts */
	IEC0bits.U1RXIE = 1;
	LED_PIN = 1;
	
	if( refGps )
		InitGps();
	
	ClrWdt();
}

void Init()
{
	ADCON1bits.ADON = 0;
	ADPCFG = 0xffff;
	
#ifdef USB_BOARD
	TRISB = 0x1aff;
#else
	TRISB = 0x18ff;
#endif
	PORTB = 0x00;

	TRISC = 0x4000;
	TRISD = 0xfdf0;
	TRISF = 0xfffc;
	TRISAbits.TRISA11 = 1;
	
	portD = 0x08; 
	LATD = portD;
	
	BYTE_PIN = 0;
	LED_PIN = 1;
	
	RCONbits.SWDTEN = 0;

	baudSwitch = ReadBaudModeSwitch();
	SetBaudRate( FALSE );
		
	TMR1 = 0; 				/* clear timer1 register */
	PR1 = 15999; 			/* set period1 register */
	T1CONbits.TCS = 0; 		/* set internal clock source */
	IPC0bits.T1IP = 0x06;	/* set priority level */
	IFS0bits.T1IF = 0; 		/* clear interrupt flag */
	T1CONbits.TON = 1; 		/* start the timer */
	SRbits.IPL = 3; 		/* enable CPU priority levels 4-7*/

	timeTick = ppsTick = 0;

	ledPPS = 0;
	numChannels = 1;
	spsRate = 100;
	sampleTimerValue = TICKS_SPS_10_200;
	timeRefType = 0;
	refGps = refLoc = 0;
	ppsHiToLowFlag = 0;
	watchdogCheck = gpsLastChar = needTimeFlag = 0;
	gpsTimer = 0;	
	adLoopCount = 24;
	sampleCountTest = 10;
		
	exitLoop = 0;
	DelayMs( 50 );
	sendLog = 0;
	newCommandFlag = checkErr = 0;
	goodConfig = 0;
	noGpsMessages = 0;
}
