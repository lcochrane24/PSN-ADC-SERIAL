/* sdrint.c */

void __attribute__((__interrupt__, no_auto_psv)) _U1TXInterrupt(void)
{
	if( txOutCount )  {
		U1TXREG = *txOutPtr++;
		--txOutCount;
	}
	else if( gpsOutSendLen ) {
		txOutCount = gpsOutSendLen;
		txOutPtr = gpsOutSendPtr;
		gpsOutSendLen = 0;
		U1TXREG = *txOutPtr++;
		--txOutCount;
	}
	else
	    IEC0bits.U1TXIE = 0;
	IFS0bits.U1TXIF = 0;
}

void __attribute__((__interrupt__, no_auto_psv)) _U2TXInterrupt(void)
{
	if( tx2OutCount )  {
		U2TXREG = *tx2OutPtr++;
		--tx2OutCount;
	}
	else
	    IEC1bits.U2TXIE = 0;
	IFS1bits.U2TXIF = 0;
}

void __attribute__((__interrupt__, no_auto_psv)) _U1RXInterrupt(void)
{
	BYTE d;
					
	if( U1STAbits.OERR )
		U1STAbits.OERR = 0;

	while( U1STAbits.URXDA )  {
		if( U1STAbits.OERR )
			U1STAbits.OERR = 0;

		if( U1STAbits.FERR != 0 )  {
			d = U1RXREG;
			continue;
		}

		d = U1RXREG;
		if( !hdrState )  {
			if( d == 0x02 )  {
				inPtr = inBuffer;
				commTimer = 0;
				inSum = 0;
				hdrState = 1;
			}
			continue;
		}
		if( hdrState == 1 )  {
			inSum ^= d;
			*inPtr++ = d;
			if( d == 'C' )  {
				inPacketLen = inDataLen = sizeof( ConfigInfo ) + 2;
				hdrState = 2;
			}
			else if( d == 'T'  || d == 'D' )  {
				inPacketLen = inDataLen = sizeof( TimeInfo ) + 2;
				hdrState = 2;
				timeStamp = timeTick;
			}
			else if( d == 'd' )  {
				inPacketLen = inDataLen = sizeof( TimeDiffInfo ) + 2;
				hdrState = 2;
			}
			else {
				inPacketLen = inDataLen = 2;
				hdrState = 2;
			}
			continue;
		}
		if( hdrState == 2 )  {
			if( inDataLen >= 3 )
				inSum ^= d;
			*inPtr++ = d;
			--inDataLen;
			if( !inDataLen )  {
				if( d != 0x03 )  {
					hdrState = 0;
					continue;
				}
				if( inSum == inBuffer[ inPacketLen-1 ] )  {
					hdrState = 3;
					newCommandFlag = TRUE;
					checkErr = 0;
				}
				else  {
					hdrState = 0;
					checkErr = 1;
				}
			}
		}
	}
	IFS0bits.U1RXIF = 0;
}

void __attribute__((__interrupt__, no_auto_psv)) _U2RXInterrupt(void)
{
	BYTE d;
	
	if( U2STAbits.OERR )
		U2STAbits.OERR = 0;
					
	while( U2STAbits.URXDA )  {
		if( U2STAbits.OERR )  {
			U2STAbits.OERR = 0;
		}
		if( U2STAbits.FERR != 0 )  {
			d = U2RXREG;
			continue;
		}
		gpsInQueue[ gpsQueueInCount ] = U2RXREG;
		if( ++gpsQueueInCount >= GPS_IN_QUEUE )
			gpsQueueInCount = 0;
	}
	
	IFS1bits.U2RXIF = 0;
}
			
inline void TimeTick()
{
	if( ledPPS )  {
		--secTick;
		if( !secTick )  {
			secTick = 1000;
			LED_PIN = 1;
		}
		else if( secTick < 500 )
			LED_PIN = 0;
	}
	
	--sampleTimer;
	if( !sampleTimer )  {
		sampleTimer = sampleTimerValue;
		newSampleFlag = 1;
	}
	
	// end of day
	if( ++timeTick >=  86400000 )
		timeTick = 0;
	
}

void __attribute__((__interrupt__, no_auto_psv)) _T1Interrupt(void)
{
//	TEST1_PIN = 1;
		
	if( addTime )  {
		TimeTick();
		addTime = 0;
	}
	
	if( !subTime )
		TimeTick();
	else
		subTime = 0;
		
	if( refGps )  {
		if( ppsHiToLowFlag )  {
			if( ppsLowHiFlag && PPS_PIN )  {
				ppsTick = timeTick;
				ppsLowHiFlag = 0;
				gpsInCount = 0;
				needTimeFlag = TRUE;
			}	
			else if( !PPS_PIN )  {
				ppsLowHiFlag = 1;
			}
		}
		else  {
			if( ppsLowHiFlag && !PPS_PIN )  {
				ppsTick = timeTick;
				ppsLowHiFlag = 0;
				gpsInCount = 0;
				needTimeFlag = TRUE;
			}	
			else if( PPS_PIN )  {
				ppsLowHiFlag = 1;
			}
		}
		++gpsTimer;
	}
		
//	TEST1_PIN = 0;
	IFS0bits.T1IF = 0;		/* clear interrupt flag */
}
